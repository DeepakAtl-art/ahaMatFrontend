INSERT INTO workouts (title, description, level, media_url)
VALUES 
('Morning Yoga', 'A light yoga session for beginners', 'beginner', 'https://example.com/yoga.jpg'),
('HIIT Blast', 'High intensity interval training for fat loss', 'intermediate', 'https://example.com/hiit.jpg'),
('Strength Training', 'Advanced strength workout', 'advance', 'https://example.com/strength.jpg');
